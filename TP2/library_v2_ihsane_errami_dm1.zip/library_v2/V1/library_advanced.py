from __future__ import annotations
from abc import ABC
from enum import Enum
from random import random, randint
import random

# Advanced version of the mini project
# For a more advanced version, use error mechanism if no book are obtained after a borrow or if a user is not allowed to borrow a book
# Add a mechanism so that any user can borrow a different number of books

#Random bounds
MIN_PAGE = 100
MAX_PAGE = 1000
MIN_BOOK = 1
MAX_BOOK = 1

# Singleton metaclass, needed to make the Library unique in memory
# You are not supposed to know this code, only that it exists
# Singleton metaclass is very generic, can be found online
# Should be adapted if any parameters needed
class Singleton(type):
    _instances = {}
    def __call__(cls, *args, **kwargs):
        if cls not in cls._instances:
            cls._instances[cls] = super(Singleton, cls).__call__(*args, **kwargs)
        return cls._instances[cls]

# Enum class for Genre: genre can only ba among a predefined list
class Genre(Enum):
    FICTION = "Fiction"
    NON_FICTION = "Non-Fiction"
    MYSTERY = "Mystery"
    FANTASY = "Fantasy"
    SCIFI = "Science Fiction"
    BIOGRAPHY = "Biography"
    HISTORY = "History"
    COMEDY = "Comedy"
    ROMANCE = "Romance"
    THRILLER = "Thriller"
    CHILDREN = "Children"
    ADVENTURE = "Adventure"

# ABC super-class: Abstract Class: make it impossible to create a Person
# Only User and Writer should exist in the program
class Person(ABC):
    def __init__(self, name:str, age:int) -> None:
        self.name = name
        self.age = age

    def __repr__(self) -> str:
        return f"[{type(self).__name__}] {self.name} ({self.age} years old)"

class Writer(Person):
    def __init__(self, name:str, age:int) -> None:
        super().__init__(name, age)
        self.written = set()

    # ToDo: should create a Book with title, nb_pages, genres, coathor and add self as author. Once done, must notify the Library about creation
    def write(self, title:str, nb_pages:int=randint(MIN_PAGE, MAX_PAGE), genres=None, coauthor:list[Writer]=None) -> Book:
        if coauthor is None: 
            coauthor = []
        book = Book(title, genres, nb_pages, self) 
        if book not in self.written:
            self.written.add(book) # add book
        for author in coauthor:
            book.addAuthor(author)
        WriteListener().notifyListeners(self, book) #Notify listeners about the new book
        return book

class User(Person):
    def __init__(self, name:str, age:int) -> None:
        super().__init__(name, age)
        self.read = []
        # __attributes: "private", can not be accessed by anything else
        self.__borrowed = []

    def readBook(self, book:Book):
        self.read.append(book)

    def getListTitleRead(self) -> list[str]:
        titles = list()
        for book in self.read :
            titles.append(book.title)
        return titles

    def getDictGenreRead(self) -> dict[Genre, int]:
        genres = dict()
        for book in self.read:
            for genre in book.genres:
                if genre not in genres:
                    genres[genre] = 1
                else:
                    genres[genre] += 1
        return genres

    # ToDo: Must borrow a book from the library with following algo
    # 1 get the titles of available books
    # 2: Select a random titles among them, using randint or choice
    # 3: Ask to the library for the Book
    # 4: Wait for the book in another method
    def borrowRandomBook(self) -> None:
        library = Library()
        available = library.consult(self)
        if not available: 
            print(f"No books available for {self.name} to borrow.")
            return

        book_title = available[randint(0, len(available) - 1)]
        print(f"{self.name} selected the book: {book_title}")

        borrowed_book = library.borrow(book_title, self)
        if borrowed_book:
            self.__borrowed.append(borrowed_book)
            print(f"{self.name} successfully borrowed: {borrowed_book}")
        else:
            print(f"{self.name} could not borrow the book: {book_title}. Waiting for it to become available.")
        print(f"Books currently borrowed by {self.name}: {self.__borrowed}")

    # ToDo: get the requested book
    def obtainBook(self, book: Book) -> None:
        library = Library()
        if book in library.__available and library.__available[book] > 0:
            self.__borrowed.append(book)
            library.borrow(book.title, self) 
            print(f"{self.name} has successfully obtained the book: {book.title}")
        else:
            print(f"{self.name} cannot obtain the book: {book.title}. It is not available.")   

    # ToDo: must return a book, algo of your choice
    def returnBook(self, book: Book) -> None:
        library = Library()
        if book in self.__borrowed:
            self.__borrowed.remove(book)
            library.returnBook(book.title, self)
            print(f"{self.name} has successfully returned the book: {book.title}")
        else:
            print(f"{self.name} cannot return the book: {book.title}. It is not borrowed.")

    def nbBorrowed(self) -> int:
        return len(self.__borrowed)
    
    def listenWriter(self, writer : Writer, library : Library)-> None : 
        WriteListener().addListener(writer, self)
        print(f"{self.name} is now listening {writer.name}.")

    def borrowWithProbability(self, book: Book, library : Library, p : float) -> None:
        if random.random() < p:
            library.reserveBook(book, self)
            print(f"{self.name} borrowed the book '{book.title}' with a probability of {p}.")
        else:
            print(f"{self.name} did not borrow the book '{book.title}' with a probability of {p}.")
        
#Listener class: must be notified by the Writer when a book is written
class WriteListener:
    def __init__(self):
        self.listeners = {}

    def addListener(self, writer: Writer, user: User):
        if writer not in self.listeners:
            self.listeners[writer] = set()
        self.listeners[writer].add(user)

    def notifyListeners(self, writer: Writer, book: Book):
        if writer in self.listeners:
            for user in self.listeners[writer]:
                print(f"Notification: {user.name}, the book '{book.title}' by {writer.name} is now available!")
                user.borrowWithProbability(book, p=0.5) #proba à 50%
class Book:
    def __init__(self, title:str, genres: set[Genre], nb_pages:int, author:Writer=None) -> None:
        self.title    :str = title
        self.nb_pages :int = nb_pages
        self.genres = genres
        self.authors  : set[Writer] = set()
        self.authors.add(author)

    def __repr__(self) -> str:
        return f"[{type(self).__name__}] {self.title} ({self.nb_pages} pages), written by {self.getListAuthorsName()}"

    # ToDo: define how to compare two books
    def __eq__(self, other:Book) -> bool:
        if not isinstance(other, Book):
            return NotImplemented
        return self.title == other.title

    # Necessary for set and such, just copy/paste from the internet
    def __hash__(self):
        return hash(self.title)

    # ToDo
    def getListAuthorsName(self) -> list[str]:
        return [author.name for author in self.authors]

    # ToDo
    def addAuthor(self, author: Writer):
        if author not in self.authors:
            self.authors.add(author)
        
# Proxy class: a cleaner search in your database
# Your user should only have access to the title of the book, not the whole data
# Therefore, when asking to borrow a book, it can only submit a title
# The library will create a "false" book with only a title to compare Book (and not a str and a Book)
# ProxyBook MUST inherit from Book to "be" a book and allow the __eq__ to works
class ProxyBook(Book):
    def __init__(self, title: str):
        super().__init__(title, genres=set(), nb_pages=0)

# Singleton class: Only one instance of Library should exist in memory
# Therefore, Person does not need a pointer to a library anymore
# They can just "create" a new one, and will obtain the already existing one
class Library(metaclass=Singleton):
    def __init__(self) -> None:
        self.name = "Library of Alexandria"
        self.__registered: set[User] = set()
        self.__available : dict[Book, int] = dict()
        self.__followed: set[Writer] = set()

    def __repr__(self):
        return f"[{type(self).__name__}] {self.name}, {len(self.__registered)} registered and {self.__totalStock()} books available."

    # ToDo: various utilitary private methods
    def __totalStock(self) -> int:
        total = 0
        for book, quantity in self.__available.items():
            total += quantity
        return total

    def __addBook(self, book: Book, qte: int = 1) -> None:
        if book in self.__available:
            self.__available[book] += qte
        else:
            self.__available[book] = qte

    def __removeBook(self, book: Book) -> None:
        if book in self.__available:
            del self.__available[book]
        else:
            #Message d'erreur
            raise ValueError(f"Book not found in library: {book.title}")

    # ToDo: register and unregister users
    def register(self, user:User) -> None:
        self.__registered.add(user)

    def unregister(self, user:User) -> None:
        self.__registered.remove(user)
        print(f"{user.name} has been unregistered from the library.")

    # Become interested in a writer
    def follow(self, writer: Writer) -> None:
        self.__followed.add(writer)

    # Get notified by a writer that a book has been writen
    # If interested, add the book in a random quantity
    def notice(self, book: Book, writer:Writer) -> None:  #object singleton <- observer altérée
        if writer in self.__followed:
            quantity = randint(1, 5)
            library = Library()
            library.__addBook(book, quantity)

    # ToDo: return the list of title of available books
    def consult(self, user: User) -> list[str]:
        return [book.title for book in self.__available.keys()]

    # ToDo: let a user borrow a book
    # The user must be registered and allowed to borrow book
    # Find the book by the name (use a Proxy) and give that book to the user
    # -> Book|None : return a Book or None
    def borrow(self, title: str, user:User) -> Book|None:
        library = Library()
        book= ProxyBook(title)
        if book in library.__available:
            book = list(library.__available.keys())[list(library.__available).index(book)]
        else:
            return None        

    # ToDo
    def returnBook(self, book: Book) -> None:
        library = Library()
        if book is None: 
            print("Cannot return a book that does not exist.")
            return
        if book in library.__available:
            library.__available[book] += 1
        else:
            library.__addBook(book, 1)
        print(f"{book.title} has been returned to the library.")

    def reserveBook(self, book : Book, user: User) -> None:
        if book in self.__available:
            self.__available[book] -= 1
            if self.__available[book] == 0:
                del self.__available[book]
            user.readBook(book)
            print(f"{user.name} reserved '{book.title}'")
        else:
            print(f"Sorry, '{book.title}' is not available in the library.")

    def notifyAvailability(self, book: Book) -> None:
        for writer in self.__followed:
            if book in writer.written:
                print(f"Notification: {writer.name}, the book '{book.title}' is now available!")